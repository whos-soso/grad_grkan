#!/bin/bash

python optuna_node_classification_kan.py 
python test_optuna_kan.py
