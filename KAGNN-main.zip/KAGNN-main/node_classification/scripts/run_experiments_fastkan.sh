#!/bin/bash

python optuna_node_classification_fastkan.py 
python test_optuna_fastkan.py
