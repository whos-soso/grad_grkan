#!/bin/bash

python optuna_node_classification_mlp.py 
python test_optuna_mlp.py
