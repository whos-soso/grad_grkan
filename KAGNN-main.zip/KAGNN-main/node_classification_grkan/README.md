To retrieve the results for node classification run:

```bash
bash scripts/run_experiments_kan.sh

bash scripts/run_experiments_mlp.sh
```

The results will be saved in the 'results' directory.
