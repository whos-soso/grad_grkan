To retrieve the results for node classification run:

```bash
bash /kaggle/working/KAGNN/node_classification_clean/scripts/run_experiments_kan.sh

bash /kaggle/working/KAGNN/node_classification_clean/scripts/run_experiments_mlp.sh
```

The results will be saved in the 'results' directory.
